function add(x, y, doResult) {
	setTimeout(function() {
		doResult(x + y + '<+>');
	}, 1000);
}

function sub(x, y, doResult) {
	setTimeout(function() {
		doResult(x - y + '<->');
	}, 1000);
}

function mul(x, y, doResult) {
	setTimeout(function() {
		doResult(x * y + '<*>');
	}, 1000);
}

function div(x, y, doResult) {
	setTimeout(function() {
		doResult((x / y).toFixed(2) + '</>');
	}, 1000);
}

module.exports = {
	add: add,
	sub: sub,
	mul: mul,
	div: div,
}