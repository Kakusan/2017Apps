var a = 1, b = 2;
var job1 = 'job(' + a + ',' + b + ')';
console.log(job1);
var result1 = a + b + '<+>';
console.log('\t' + job1 + ' = ' + result1);

var c = 3, d = 4;
var job2 = 'job(' + c + ',' + d + ')';
console.log(job2);
var result2 = c + d + '<+>';
console.log('\t' + job2 + ' = ' + result2);

var e = 5, f = 6;
var job3 = 'job(' + e + ',' + f + ')';
console.log(job3);
var result3 = e + f + '<+>';
console.log('\t' + job3 + ' = ' + result3);